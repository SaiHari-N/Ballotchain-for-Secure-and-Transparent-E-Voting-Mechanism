<ul class="nav" id="main-menu">

                   <!-- <li>
                        <a class="active-menu" href="vote_count.php"><i class="fa fa-dashboard"></i> Dashboard</a>
                    </li>-->
					 <li>
                        <a class="active-menu" href="add_election.php"><i class="fa fa-table"></i> Election</a>
                    </li>
                    <!--<li>
                        <a href="view_voter.php"><i class="fa fa-desktop"></i> Voter</a>
                    </li> -->
					 
					 <li>
                        <a href="#"><i class="fa fa-sitemap"></i> Voter<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="add_voter.php">Add New</a>
                            </li>
                            <li>
                                <a href="view_voter.php">View Voters</a>
                            </li>
							</ul>
						</li>
						
						
							<li>
                        <a href="#"><i class="fa fa-sitemap"></i> Officer<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="add_officer1.php">Returning Officer</a>
                            </li>
                            <li>
                                <a href="add_officer2.php">Presiding Officers</a>
                            </li>
							<li>
                                <a href="add_officer3.php">Polling Officers</a>
                            </li>
							</ul>
						</li>
							
                   <!-- <li>
                        <a href="tab-panel.html"><i class="fa fa-qrcode"></i> Result</a>
                    </li>-->
                    
                    <li>
                        <a href="result.php"><i class="fa fa-table"></i> Result</a>
                    </li>
                   <!-- <li>
                        <a href="form.html"><i class="fa fa-edit"></i> Forms </a>
                    </li>


                    <li>
                        <a href="#"><i class="fa fa-sitemap"></i> Multi-Level Dropdown<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="#">Second Level Link</a>
                            </li>
                            <li>
                                <a href="#">Second Level Link</a>
                            </li>
                            <li>
                                <a href="#">Second Level Link<span class="fa arrow"></span></a>
                                <ul class="nav nav-third-level">
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>

                                </ul>

                            </li>
                        </ul>
                    </li>-->
                    <li>
                        <a href="logout.php"><i class="fa fa-fw fa-file"></i> Logout</a>
                    </li>
                </ul>