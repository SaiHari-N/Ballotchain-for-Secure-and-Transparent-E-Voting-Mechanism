<ul class="nav" id="main-menu">

                    <li>
                        <a class="active-menu" href="home_auth.php"><i class="fa fa-dashboard"></i> Home</a>
                    </li>
					<li>
                        <a href="view_block.php"><i class="fa fa-dashboard"></i> Vote Blocks</a>
                    </li>
					 <li>
                        <a href="view_attack.php"><i class="fa fa-dashboard"></i> Attacks</a>
                    </li>
                  
                    <li>
                        <a href="logout.php"><i class="fa fa-fw fa-file"></i> Logout</a>
                    </li>
                </ul>