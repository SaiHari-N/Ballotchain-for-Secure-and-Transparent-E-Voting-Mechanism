<ul class="nav" id="main-menu">

                    <li>
                        <a class="active-menu" href="home.php"><i class="fa fa-dashboard"></i> Home</a>
                    </li>
                  
						<li>
                        <a href="#"><i class="fa fa-sitemap"></i> Candidates<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="add_candidate.php">Add New</a>
                            </li>
                            <li>
                                <a href="view_candidate.php">View Candidates</a>
                            </li>
							</ul>
						</li>
                    <li>
                        <a href="logout.php"><i class="fa fa-fw fa-file"></i> Logout</a>
                    </li>
                </ul>