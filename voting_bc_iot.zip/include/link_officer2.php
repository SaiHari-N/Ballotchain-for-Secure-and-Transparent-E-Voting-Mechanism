<ul class="nav" id="main-menu">

                    <li>
                        <a class="active-menu" href="booth_home.php"><i class="fa fa-dashboard"></i> Home</a>
                    </li>
                  
                    <li>
                        <a href="logout.php"><i class="fa fa-fw fa-file"></i> Logout</a>
                    </li>
                </ul>