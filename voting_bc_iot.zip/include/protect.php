<?php
session_start();
if($_SESSION['voterid']=="")
{
//header("location:index.php");
}
?>