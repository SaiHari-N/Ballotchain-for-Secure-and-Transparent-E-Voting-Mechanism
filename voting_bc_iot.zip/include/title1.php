<span style="font-size:18px"><?php
echo "ELECTION COMMISSION";
?></span>